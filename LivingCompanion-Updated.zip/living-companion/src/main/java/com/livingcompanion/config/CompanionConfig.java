package com.livingcompanion.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Simple server-authoritative settings for the companion's core systems. */
public final class CompanionConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.DoubleValue MAX_HEALTH;
    public static final ForgeConfigSpec.DoubleValue ATTACK_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue MOVEMENT_SPEED;
    public static final ForgeConfigSpec.DoubleValue FOLLOW_START_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue FOLLOW_STOP_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue TELEPORT_DISTANCE;
    public static final ForgeConfigSpec.DoubleValue HOSTILE_SCAN_RANGE;
    public static final ForgeConfigSpec.IntValue RESURRECTION_DELAY_SECONDS;
    public static final ForgeConfigSpec.BooleanValue DIALOGUE_ENABLED;
    public static final ForgeConfigSpec.IntValue DIALOGUE_COOLDOWN_SECONDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("companion");
        MAX_HEALTH = b.comment("Companion maximum health.")
                .defineInRange("maxHealth", 40.0D, 10.0D, 200.0D);
        ATTACK_DAMAGE = b.comment("Base melee damage before weapon bonuses.")
                .defineInRange("attackDamage", 6.0D, 1.0D, 40.0D);
        MOVEMENT_SPEED = b.comment("Movement speed.")
                .defineInRange("movementSpeed", 0.28D, 0.10D, 1.0D);
        b.pop();

        b.push("following");
        FOLLOW_START_DISTANCE = b.comment("Start following beyond this distance.")
                .defineInRange("startDistance", 5.0D, 2.0D, 32.0D);
        FOLLOW_STOP_DISTANCE = b.comment("Stop moving toward the owner inside this distance.")
                .defineInRange("stopDistance", 2.5D, 1.0D, 16.0D);
        TELEPORT_DISTANCE = b.comment("Catch-up teleport distance. Set to 0 to disable.")
                .defineInRange("teleportDistance", 32.0D, 0.0D, 128.0D);
        b.pop();

        b.push("combat");
        HOSTILE_SCAN_RANGE = b.comment("Range used to find hostile monsters.")
                .defineInRange("hostileScanRange", 16.0D, 4.0D, 48.0D);
        b.pop();

        b.push("resurrection");
        RESURRECTION_DELAY_SECONDS = b.comment("Delay before the companion returns at the owner's bed.")
                .defineInRange("delaySeconds", 120, 0, 86400);
        b.pop();

        b.push("dialogue");
        DIALOGUE_ENABLED = b.comment("Enable occasional companion dialogue.")
                .define("enabled", true);
        DIALOGUE_COOLDOWN_SECONDS = b.comment("Minimum delay between random dialogue lines.")
                .defineInRange("cooldownSeconds", 90, 15, 3600);
        b.pop();

        SPEC = b.build();
    }

    private CompanionConfig() { }
}
